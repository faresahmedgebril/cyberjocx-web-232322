import { ReactNode, useState } from "react"
import brandMark from "@/imports/WhatsApp_Image_2026-10-10_at_7.09.03_PM__1_.jpeg"
import hoodedImage from "@/imports/WhatsApp_Image_2026-10-10_at_7.12.31_PM__1_.jpeg"

type IconName =
  | "home" | "book" | "roadmap" | "courses" | "trophy" | "community"
  | "bell" | "user" | "dashboard" | "path" | "layers" | "flask" | "quiz"
  | "certificate" | "search" | "grid" | "levels" | "tag" | "reset"
  | "clock" | "check" | "network" | "globe" | "terminal" | "firewall"
  | "linux" | "windows" | "shield" | "directory" | "triad" | "lock"
  | "hash" | "warning" | "target" | "forensic" | "cloud" | "api"
  | "code" | "mobile" | "gear" | "radar" | "folder" | "lab" | "chevron"

const iconPaths: Record<IconName, ReactNode> = {
  home: <><path d="m3 11 9-8 9 8" /><path d="M5 10v10h5v-6h4v6h5V10" /></>,
  book: <><path d="M4 5a3 3 0 0 1 3-2h5v17H7a3 3 0 0 0-3 2Z" /><path d="M20 5a3 3 0 0 0-3-2h-5v17h5a3 3 0 0 1 3 2Z" /></>,
  roadmap: <><path d="M4 4h6v6H4zM14 14h6v6h-6z" /><path d="M10 7h4a3 3 0 0 1 3 3v4M7 10v8h7" /></>,
  courses: <><path d="m2.5 8.5 9.5-5 9.5 5-9.5 5Z" /><path d="M6 11v5.5c3.8 2.7 8.2 2.7 12 0V11M21.5 8.5V15" /></>,
  trophy: <><path d="M8 4h8v5a4 4 0 0 1-8 0V4Z" /><path d="M8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4M12 13v5M8 21h8" /></>,
  community: <><circle cx="9" cy="8" r="3" /><circle cx="17" cy="10" r="2" /><path d="M3 20a6 6 0 0 1 12 0M14 17a5 5 0 0 1 7 3" /></>,
  bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9ZM10 21h4" /></>,
  user: <><circle cx="12" cy="8" r="4" /><path d="M4 21a8 8 0 0 1 16 0" /></>,
  dashboard: <><path d="M4 13h6V4H4zM14 20h6v-9h-6zM4 20h6v-3H4zM14 7h6V4h-6z" /></>,
  path: <><path d="m3 6 5-3 5 3-5 3Z" /><path d="m11 17 5-3 5 3-5 3ZM8 9v4c0 2.2 1.8 4 4 4h4" /></>,
  layers: <><path d="m12 2 9 5-9 5-9-5Z" /><path d="m3 12 9 5 9-5M3 17l9 5 9-5" /></>,
  flask: <><path d="M9 3h6M10 3v6l-6 10a1.8 1.8 0 0 0 1.6 2.7h12.8A1.8 1.8 0 0 0 20 19L14 9V3" /><path d="M7 15h10" /></>,
  quiz: <><path d="M6 3h12v18H6z" /><path d="M9 7h6M9 11h6M9 15h3" /><path d="m15 16 1 1 2-3" /></>,
  certificate: <><path d="M12 2 15 4l3.5.2.8 3.4L22 10l-1.4 3.2.5 3.5-3.3 1.5L16 21l-4-1-4 1-1.8-2.8-3.3-1.5.5-3.5L2 10l2.7-2.4.8-3.4L9 4Z" /><path d="m8.5 11 2.2 2.2 4.8-5" /></>,
  search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
  grid: <><rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" /><rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" /></>,
  levels: <><circle cx="12" cy="4" r="2" /><circle cx="5" cy="19" r="2" /><circle cx="19" cy="19" r="2" /><path d="M12 6v5M5 17v-3h14v3M12 11v3" /></>,
  tag: <><path d="M20 13 13 20 3 10V3h7Z" /><circle cx="7.5" cy="7.5" r="1" /></>,
  reset: <><path d="M4 4v6h6" /><path d="M5.5 15a8 8 0 1 0 .7-7.8L4 10" /></>,
  clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
  check: <><path d="M4 5h16v16H4z" /><path d="m8 13 3 3 5-7" /></>,
  network: <><circle cx="12" cy="4" r="2" /><circle cx="5" cy="18" r="2" /><circle cx="19" cy="18" r="2" /><circle cx="12" cy="12" r="2" /><path d="m11 6-5 10m7-10 5 10M7 18h10m-4-4 4 3m-6-3-4 3" /></>,
  globe: <><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18" /></>,
  terminal: <><rect x="2" y="3" width="20" height="18" rx="2" /><path d="m6 8 4 4-4 4M12 16h6" /></>,
  firewall: <><path d="M4 4h16v16H4zM4 9h16M4 15h16M9 4v5m6 0v6M9 15v5" /></>,
  linux: <><path d="M8 10c0-5 1.5-8 4-8s4 3 4 8c2 2 3 5 2 9H6c-1-4 0-7 2-9Z" /><circle cx="10" cy="8" r=".6" fill="currentColor" /><circle cx="14" cy="8" r=".6" fill="currentColor" /><path d="m10 11 2 1 2-1M8 18l-3 3m11-3 3 3" /></>,
  windows: <><path d="m3 5 8-1v8H3zm10-1 8-1v9h-8zM3 14h8v7l-8-1zm10 0h8v8l-8-1z" /></>,
  shield: <><path d="M12 2 4 5v6c0 5 3.4 8.6 8 11 4.6-2.4 8-6 8-11V5Z" /><path d="m8 12 3 3 5-7" /></>,
  directory: <><path d="M3 6h7l2 2h9v12H3Z" /><path d="M8 16v-5h8v5M12 11v5" /></>,
  triad: <><path d="M12 3 3 20h18Z" /><path d="M12 3v17M3 20l13.5-8" /></>,
  lock: <><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3" /></>,
  hash: <><path d="M9 3 7 21M17 3l-2 18M4 9h16M3 15h16" /></>,
  warning: <><path d="m12 3 10 18H2Z" /><path d="M12 9v5M12 18h.01" /></>,
  target: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /><path d="m16 8 5-5M17 3h4v4" /></>,
  forensic: <><circle cx="10" cy="10" r="6" /><path d="m14.5 14.5 6 6M8 10h4M10 8v4" /></>,
  cloud: <path d="M6 19h12a4 4 0 0 0 .5-8A7 7 0 0 0 5 9a5 5 0 0 0 1 10Z" />,
  api: <><path d="m7 3-4 4 4 4M17 3l4 4-4 4M7 13l-4 4 4 4M17 13l4 4-4 4" /><path d="m14 2-4 20" /></>,
  code: <><path d="m8 6-6 6 6 6M16 6l6 6-6 6M14 3l-4 18" /></>,
  mobile: <><rect x="7" y="2" width="10" height="20" rx="2" /><path d="M10 5h4M11 19h2" /></>,
  gear: <><circle cx="12" cy="12" r="3" /><path d="M19 12a7 7 0 0 0-.1-1l2-1.5-2-3.4-2.4 1a7 7 0 0 0-1.7-1L14.5 3h-5l-.4 3.1a7 7 0 0 0-1.7 1L5 6.1 3 9.5 5.1 11a7 7 0 0 0 0 2L3 14.5l2 3.4 2.4-1a7 7 0 0 0 1.7 1l.4 3.1h5l.4-3.1a7 7 0 0 0 1.7-1l2.4 1 2-3.4-2.1-1.5c.1-.3.1-.7.1-1Z" /></>,
  radar: <><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><path d="M12 12 20 7M12 3v3M3 12h3M12 18v3" /></>,
  folder: <><path d="M3 6h7l2 2h9v12H3Z" /><path d="m9 16 2-2-2-2m4 4h3" /></>,
  lab: <><path d="M9 3h6M10 3v6l-6 10a1.8 1.8 0 0 0 1.6 2.7h12.8A1.8 1.8 0 0 0 20 19L14 9V3" /><path d="M8 16h8" /></>,
  chevron: <path d="m9 6 6 6-6 6" />,
}

function Icon({ name, size = 22 }: { name: IconName; size?: number }) {
  return <svg className="icon" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{iconPaths[name]}</svg>
}

const menuItems: { label: string; icon: IconName }[] = [
  { label: "Home", icon: "home" }, { label: "Dashboard", icon: "dashboard" },
  { label: "Courses", icon: "book" }, { label: "Roadmap", icon: "roadmap" },
  { label: "Labs", icon: "flask" }, { label: "Challenges", icon: "shield" },
  { label: "CVE Center", icon: "certificate" }, { label: "Malware", icon: "warning" },
  { label: "Community", icon: "community" }, { label: "Market", icon: "tag" },
  { label: "AI Assistant", icon: "gear" },
]

const leaders = [
  { rank: 1, user: "ShadowHacker", points: "12,450", tier: "Elite", level: 85, color: "pink" },
  { rank: 2, user: "CyberWolf", points: "11,230", tier: "Expert", level: 78, color: "blue" },
  { rank: 3, user: "JocxMaster", points: "10,870", tier: "Expert", level: 76, color: "cyan" },
  { rank: 4, user: "DarkPhoenix", points: "9,750", tier: "Advanced", level: 71, color: "green" },
  { rank: 5, user: "HackerPro", points: "8,920", tier: "Advanced", level: 68, color: "green" },
  { rank: 6, user: "NetSecKing", points: "8,410", tier: "Intermediate", level: 62, color: "silver" },
  { rank: 7, user: "ByteRider", points: "7,930", tier: "Intermediate", level: 59, color: "silver" },
]

export default function App() {
  const [period, setPeriod] = useState("All Time")
  return <div className="leaderboard-shell">
    <header className="leader-topbar">
      <label><Icon name="search" size={21} /><input placeholder="Search anything..." /></label>
      <div className="leader-actions"><button aria-label="Notifications"><Icon name="bell" size={21} /><i /></button><button aria-label="Theme"><span>◐</span></button><span className="mini-avatar"><img src={hoodedImage} alt="" /></span><strong>Yassen</strong><Icon name="chevron" size={14} /></div>
    </header>
    <aside className="leader-sidebar">
      <a className="leader-brand" href="#" aria-label="CyberJocx home"><img src={brandMark} alt="" /><strong>Cyber<span>Jocx</span></strong></a>
      <nav>{menuItems.map((item) => <button key={item.label}><Icon name={item.icon} size={20} /><span>{item.label}</span></button>)}</nav>
      <div className="side-divider" />
      <button className="side-track"><Icon name="layers" size={20} /><span>Tracks</span><Icon name="chevron" size={15} /></button>
      <button className="side-active"><Icon name="user" size={20} /><span>Leaderboard</span></button>
      <button><Icon name="gear" size={20} /><span>Settings</span></button>
      <button><Icon name="chevron" size={20} /><span>Log Out</span></button>
      <small>LEARN <b>•</b> PRACTICE <b>•</b> HACK <b>•</b> GROW</small>
    </aside>
    <main className="leader-main">
      <div className="leader-content">
        <section className="leader-hero">
          <header><span><Icon name="trophy" size={45} /></span><div><h1>Leaderboard</h1><p>See how you rank among the CyberJocx community</p></div></header>
          <div className="podium">
            <article className="podium-user second"><div className="winner-ring"><img src={hoodedImage} alt="" /></div><strong>CyberWolf</strong><span>★ 11,230 Pts</span><div className="podium-base"><b>2</b></div></article>
            <article className="podium-user first"><i>♛</i><div className="winner-ring"><img src={hoodedImage} alt="" /></div><strong>Yassen</strong><span>★ 12,450 Pts</span><div className="podium-base"><b>1</b></div></article>
            <article className="podium-user third"><div className="winner-ring"><img src={hoodedImage} alt="" /></div><strong>JocxMaster</strong><span>★ 10,870 Pts</span><div className="podium-base"><b>3</b></div></article>
          </div>
        </section>
        <section className="leader-board">
          <div className="period-tabs">{["All Time", "This Month", "This Week", "Today"].map((item, index) => <button className={period === item ? "active" : ""} onClick={() => setPeriod(item)} key={item}><Icon name={index === 0 ? "trophy" : index === 3 ? "clock" : "grid"} size={18} />{item}</button>)}</div>
          <div className="ranking-table">
            <div className="ranking-head"><span>#</span><span>User</span><span>Points</span><span>Rank</span><span>Level</span></div>
            {leaders.map((leader) => <div className={`ranking-row ${leader.rank === 1 ? "current" : ""}`} key={leader.user}>
              <span className="rank-number">{leader.rank}</span><span className="rank-user">{leader.rank <= 3 && <b>♛</b>}<i><img src={hoodedImage} alt="" /></i><strong>{leader.user}</strong></span>
              <span>{leader.points}</span><span><b className={`tier ${leader.color}`}><Icon name="certificate" size={15} />{leader.tier}</b></span>
              <span className={`level-bar level-${leader.rank}`}><b>Lv. {leader.level}</b><i><em /></i></span>
            </div>)}
          </div>
        </section>
      </div>
      <aside className="leader-rail">
        <section className="level-card">
          <div className="level-top"><span><small>LVL</small><b>12</b></span><div><strong>1,240 <small>/ 2,000 XP</small></strong><i><b /></i><p>Next Level: 760 XP</p></div></div>
          <div className="level-bottom"><div><Icon name="certificate" size={25} /><span><b>4,850</b><small>Points</small></span></div><div><Icon name="trophy" size={25} /><span><b>Silver</b><small>Rank</small></span></div></div>
        </section>
        <section className="quick-card"><h2><Icon name="warning" size={22} />Quick Stats</h2><div><Icon name="trophy" size={22} /><span>Total Points</span><b>6,120</b></div><div><Icon name="check" size={22} /><span>Completed Labs</span><b>48</b></div><div><Icon name="shield" size={22} /><span>Solved Challenges</span><b>12</b></div></section>
        <blockquote className="leader-quote"><b>“</b><p>Keep going, Yassen!<br />You're one step closer<br />to becoming a cybersecurity expert.</p><img src={hoodedImage} alt="" /><strong>”</strong></blockquote>
      </aside>
    </main>
  </div>
}
