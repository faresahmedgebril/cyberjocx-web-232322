import { FormEvent, useState } from "react";

function Icon({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">{children}</svg>;
}

const particles = [[8, 12, 0], [18, 62, 2.3], [32, 28, 4.1], [43, 78, 1.4], [58, 18, 3.2], [67, 55, 0.6], [78, 85, 4.8], [89, 36, 2.1]];
const codeLines = [
  "01 ACCESS GRANTED 10", "sudo ./secure --future", "7F 3A C9 00 FF 12", "while(true){learn();}",
  "01001011 10110100", "ssh root@cyberjocx", "const skill = 'power';", "nmap -sV 10.0.0.1",
  "AUTH TOKEN VERIFIED", "10110 ENCRYPT 00101", "git commit -m secure", "0x4A 0x2F 0x9D",
  "function defend() {}", "SELECT * FROM skills", "BUILD HACK GROW",
];

export default function App() {
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setMessage("Welcome back — your secure session is starting.");
  }

  return <main className="login-page">
    <div className="code-rain" aria-hidden="true">
      {codeLines.map((line, index) => <span key={line} style={{ left: `${2 + index * 6.8}%`, animationDelay: `${-(index * 1.37) % 9}s`, animationDuration: `${8 + index % 5 * 1.35}s` }}>{line}</span>)}
    </div>

    <section className="story-panel" aria-label="CyberJocx introduction">
      <div className="story-image" />
      <div className="scanline" />
      <div className="story-glow glow-one" />
      <div className="story-glow glow-two" />
    </section>

    <section className="login-side">
      <div className="circuit circuit-one" />
      <div className="circuit circuit-two" />
      <div className="particles" aria-hidden="true">
        {particles.map(([left, top, delay], index) => <i key={index} style={{ left: `${left}%`, top: `${top}%`, animationDelay: `${delay}s` }} />)}
      </div>

      <div className="signup-prompt"><span>Don't have an account?</span><a href="#signup">Sign Up</a><b>→</b></div>

      <form className="login-card" onSubmit={submit}>
        <div className="corner corner-tl" /><div className="corner corner-br" />
        <header>
          <div className="wordmark">Cyber<span>Jocx</span></div>
          <h1>Welcome <span>Back</span></h1>
          <p>Sign in to continue your cybersecurity journey</p>
        </header>

        <div className="social-row">
          <button type="button" className="social-button"><span className="google-mark">G</span>Continue with Google</button>
          <button type="button" className="social-button">
            <Icon className="github-icon"><path fill="currentColor" d="M12 2a10 10 0 0 0-3.16 19.49c.5.09.68-.22.68-.48v-1.86c-2.78.6-3.37-1.18-3.37-1.18-.45-1.15-1.11-1.46-1.11-1.46-.91-.62.07-.61.07-.61 1 .07 1.53 1.03 1.53 1.03.9 1.53 2.35 1.09 2.92.83.09-.65.35-1.09.64-1.34-2.22-.25-4.55-1.11-4.55-4.94 0-1.09.39-1.98 1.03-2.68-.1-.25-.45-1.27.1-2.64 0 0 .84-.27 2.75 1.02A9.56 9.56 0 0 1 12 6.84a9.5 9.5 0 0 1 2.5.34c1.91-1.3 2.75-1.02 2.75-1.02.55 1.37.2 2.39.1 2.64.64.7 1.03 1.59 1.03 2.68 0 3.84-2.34 4.68-4.57 4.93.36.31.68.92.68 1.86v2.76c0 .27.18.58.69.48A10 10 0 0 0 12 2Z" /></Icon>
            Continue with GitHub
          </button>
        </div>

        <div className="divider"><span>OR</span></div>
        <label className="field-label" htmlFor="identity">Username or Email</label>
        <div className="input-wrap">
          <Icon><circle cx="12" cy="7.5" r="4" /><path d="M4.5 21c.5-5 3-7 7.5-7s7 2 7.5 7" /></Icon>
          <input id="identity" type="text" placeholder="Enter your username or email" autoComplete="username" />
        </div>

        <label className="field-label" htmlFor="password">Password</label>
        <div className="input-wrap">
          <Icon><rect x="5" y="10" width="14" height="11" rx="2" /><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3" /></Icon>
          <input id="password" type={showPassword ? "text" : "password"} placeholder="Enter your password" autoComplete="current-password" />
          <button className="eye-button" type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"}>
            <Icon><path d="M2.5 12s3.5-5 9.5-5 9.5 5 9.5 5-3.5 5-9.5 5-9.5-5-9.5-5Z" /><circle cx="12" cy="12" r="2.5" />{!showPassword && <path d="m4 4 16 16" />}</Icon>
          </button>
        </div>

        <div className="form-options"><label><input type="checkbox" /><span />Remember me</label><a href="#forgot">Forgot password?</a></div>
        <button className="signin-button" type="submit"><span>Sign In</span><b>→</b></button>
        <p className={`form-message ${message ? "visible" : ""}`} role="status">{message || "Ready"}</p>

        <footer className="benefits">
          <span><Icon><path d="M12 3 20 6v6c0 4.5-3 7.5-8 9-5-1.5-8-4.5-8-9V6l8-3Z" /><path d="m9 12 2 2 4-5" /></Icon>Better Skills</span><i />
          <span><Icon><path d="m13 2-7 12h6l-1 8 7-12h-6l1-8Z" /></Icon>Stronger Security</span><i />
          <span><Icon><path d="M4 19v-4m5 4v-7m5 7V8m5 11V4" /></Icon>A Safer Tomorrow</span>
        </footer>
      </form>
    </section>
  </main>;
}
